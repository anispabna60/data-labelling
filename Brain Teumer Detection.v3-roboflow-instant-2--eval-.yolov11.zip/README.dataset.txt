# Brain Teumer Detection > Roboflow Instant 2 [Eval]
https://universe.roboflow.com/anotate-wvfjm/brain-teumer-detection-almz3

Provided by a Roboflow user
License: CC BY 4.0

